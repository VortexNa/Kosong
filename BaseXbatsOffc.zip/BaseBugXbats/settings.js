const fs = require('fs')
const chalk = require('chalk')

//Settings
global.owner = "628999379054"
global.ownername = "GulbatDevloper"
global.namabot = "☠️︎︎𝐋𝐞𝐭𝐭𝐲𝐂𝐡𝐢𝐚̷̨♨️︎"
global.versisc = "5.0"
global.simbol = "ネ"
global.zz = "`"
global.linkgc = "https://chat.whatsapp.com/Ba1PW5gSYreFfl2kQTgTfb"
global.idGc = "120363308440213757@g.us"
global.linkSaluran = "https://whatsapp.com/channel/0029VaibU8cJENy5B66lOJ1o"
global.idSaluran = "120363333019033320@newsletter"
global.namaSaluran = "© 𝗚𝘂𝗹𝗯𝗮𝘁𝗗𝗲𝘃"

// >~~~~~~~~ Setting Message ~~~~~~~~~< //
global.msg = {
wait: "Memproses . . .", 
owner: "Fitur ini khusus untuk owner!", 
premium: "Fitur ini khusus murbug 𝐋𝐞𝐭𝐭𝐲𝐂𝐡𝐢𝐚!", 
group: "Fitur ini untuk dalam grup!", 
admin: "Fitur ini untuk admin grup!", 
botadmin: "Fitur ini hanya untuk bot menjadi admin"
}
//Thumbnail
global.imgthumb = "https://img1.pixhost.to/images/6151/605839325_imgtmp.jpg"
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})